I just download all this using:

```shell
wget -r -np -A gif,f,Z,gz -l 1 https://cfl3d.larc.nasa.gov/Cfl3dv6/cfl3dv6_testcases.html
```
